/**
 * Backup data sources for the sports commands (no API keys needed):
 *   - ESPN public site API  -> scores, fixtures, results, tables, news
 *   - TheSportsDB (free)    -> player / team / venue / head-to-head search
 * Every function returns the same shape the previous API returned, so the
 * existing formatters in commands/sports/sports.js keep working unchanged.
 */
const axios = require('axios');
const cheerio = require('cheerio');

const ESPN = 'https://site.api.espn.com/apis';
// TheSportsDB permanently disabled key "3"; 123 is its published test/free key.
const TSDB = `https://www.thesportsdb.com/api/v1/json/${encodeURIComponent(process.env.SPORTSDB_API_KEY || '123')}`;
const LEAGUES = {
  epl: { code: 'eng.1', name: 'Premier League' },
  bundesliga: { code: 'ger.1', name: 'Bundesliga' },
  laliga: { code: 'esp.1', name: 'La Liga' },
  ligue1: { code: 'fra.1', name: 'Ligue 1' },
  seriea: { code: 'ita.1', name: 'Serie A' },
  ucl: { code: 'uefa.champions', name: 'UEFA Champions League' },
  euros: { code: 'uefa.euro', name: 'UEFA European Championship' },
  fifa: { code: 'fifa.world', name: 'FIFA World Cup' }
};

const get = async (url, params) => (await axios.get(url, {
  params,
  timeout: 10000,
  headers: { 'User-Agent': 'Mozilla/5.0 (compatible; TALKLESS sports bot)' }
})).data;
const ymd = d => d.toISOString().slice(0, 10).replace(/-/g, '');
const shift = days => new Date(Date.now() + days * 864e5);
const stat = (entry, name) => entry.stats?.find(s => s.name === name)?.value ?? 0;

function mapEvent(e) {
  const c = e.competitions?.[0] || {};
  const home = c.competitors?.find(x => x.homeAway === 'home') || c.competitors?.[0] || {};
  const away = c.competitors?.find(x => x.homeAway === 'away') || c.competitors?.[1] || {};
  const st = e.status?.type || {};
  const hasScore = st.state !== 'pre';
  return {
    eventId: e.id,
    homeTeam: home.team?.displayName || 'TBD',
    awayTeam: away.team?.displayName || 'TBD',
    homeScore: hasScore ? home.score : undefined,
    awayScore: hasScore ? away.score : undefined,
    score: hasScore ? `${home.score} - ${away.score}` : '',
    date: e.date ? `${e.date.slice(0, 16).replace('T', ' ')} UTC` : '',
    status: st.shortDetail || st.description || '',
    state: st.state,
    winner: st.state === 'post' ? (home.winner ? home.team?.displayName : away.winner ? away.team?.displayName : 'Draw') : '',
    league: e.league || ''
  };
}

async function scoreboard(code, from, to) {
  // ESPN documents date ranges, but its live scoreboard responds HTTP 400 to
  // multi-day ranges. Fetch single days in short batches instead.
  const days = [];
  const cursor = new Date(Date.UTC(from.getUTCFullYear(), from.getUTCMonth(), from.getUTCDate()));
  const end = Date.UTC(to.getUTCFullYear(), to.getUTCMonth(), to.getUTCDate());
  while (cursor.getTime() <= end && days.length < 22) {
    days.push(ymd(cursor));
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }
  const events = [];
  for (let i = 0; i < days.length; i += 4) {
    const batch = await Promise.all(days.slice(i, i + 4).map(async day => {
      try {
        const d = await get(`${ESPN}/site/v2/sports/soccer/${code}/scoreboard`, { dates: day, limit: 200 });
        return d.events || [];
      } catch (error) {
        console.warn(`[sports-fallback] scoreboard ${code} ${day}: ${error.message}`);
        return [];
      }
    }));
    events.push(...batch.flat());
  }
  const unique = new Map(events.map(e => [e.id, e]));
  return [...unique.values()].map(mapEvent);
}

async function fixtures(key, kind) {
  const L = LEAGUES[key];
  if (kind === 'upcoming') {
    const m = (await scoreboard(L.code, new Date(), shift(21))).filter(x => x.state === 'pre');
    return { competition: L.name, upcomingMatches: m, matches: m };
  }
  const m = (await scoreboard(L.code, shift(-21), new Date())).filter(x => x.state !== 'pre').reverse();
  return { competition: L.name, matches: m };
}

async function standings(key) {
  const L = LEAGUES[key];
  const d = await get(`${ESPN}/v2/sports/soccer/${L.code}/standings`);
  const groups = d.children?.length ? d.children : [d];
  const rows = [];
  for (const g of groups) {
    for (const e of g.standings?.entries || []) {
      rows.push({
        position: stat(e, 'rank'), team: e.team?.displayName, played: stat(e, 'gamesPlayed'),
        won: stat(e, 'wins'), draw: stat(e, 'ties'), lost: stat(e, 'losses'),
        goalsFor: stat(e, 'pointsFor'), goalsAgainst: stat(e, 'pointsAgainst'),
        goalDifference: stat(e, 'pointDifferential'), points: stat(e, 'points')
      });
    }
  }
  return { competition: L.name, standings: rows };
}

async function topScorers(key) {
  const L = LEAGUES[key];
  const url = `https://www.espn.com/soccer/stats/_/league/${encodeURIComponent(L.code)}/view/scoring`;
  const { data: html } = await axios.get(url, {
    timeout: 15000,
    headers: { 'User-Agent': 'Mozilla/5.0 (compatible; TALKLESS sports bot)' }
  });
  const $ = cheerio.load(html);
  const topScorers = [];
  $('table').first().find('tbody tr').each((index, row) => {
    const cells = $(row).find('td');
    if (cells.length < 5) return;
    const cellText = i => $(cells[i]).text().replace(/\s+/g, ' ').trim();
    const player = $(cells[1]).find('a').first().text().trim() || cellText(1);
    const team = $(cells[2]).find('a').first().text().trim() || cellText(2);
    const goals = Number.parseInt(cellText(4), 10);
    if (!player || !Number.isFinite(goals)) return;
    topScorers.push({
      rank: Number.parseInt(cellText(0), 10) || topScorers.length + 1,
      player,
      team,
      matches: Number.parseInt(cellText(3), 10) || 0,
      goals
    });
  });
  if (!topScorers.length) throw new Error('ESPN returned no scoring table for this competition.');
  return { competition: L.name, topScorers: topScorers.slice(0, 30) };
}

async function liveScores() {
  const d = await get(`${ESPN}/site/v2/sports/soccer/all/scoreboard`, { limit: 300 });
  const all = (d.events || []).map(mapEvent);
  const live = all.filter(x => x.state === 'in');
  return live.length ? live : all; // nothing live -> show today's list
}

const findTeamLeagues = Object.keys(LEAGUES);

async function news() {
  const d = await get(`${ESPN}/site/v2/sports/soccer/eng.1/news`);
  return { items: (d.articles || []).map(a => ({ title: a.headline, summary: a.description, date: (a.published || '').slice(0, 10) })) };
}

// ── TheSportsDB ──────────────────────────────────────────────────────────────
const players = async q => ((await get(`${TSDB}/searchplayers.php`, { p: q })).player || []).map(p => ({
  name: p.strPlayer, team: p.strTeam, sport: p.strSport, nationality: p.strNationality,
  position: p.strPosition, birthDate: p.dateBorn, status: p.strStatus
}));
const teams = async q => ((await get(`${TSDB}/searchteams.php`, { t: q })).teams || []).map(t => ({
  name: t.strTeam, league: t.strLeague, sport: t.strSport, stadium: t.strStadium,
  stadiumCapacity: t.intStadiumCapacity, location: t.strStadiumLocation, country: t.strCountry,
  formedYear: t.intFormedYear, social: { website: t.strWebsite }, description: t.strDescriptionEN
}));
const venues = async q => ((await get(`${TSDB}/searchvenues.php`, { v: q })).venues || []).map(v => ({
  name: v.strVenue, sport: v.strSport, capacity: v.intCapacity, location: v.strLocation,
  country: v.strCountry, description: v.strDescriptionEN
}));
const gameEvents = async q => {
  const name = q.replace(/\s+(vs\.?|v)\s+/i, ' vs ').trim().replace(/\s+/g, '_');
  const d = await get(`${TSDB}/searchevents.php`, { e: name });
  return (d.event || []).map(e => ({
    teams: { home: { name: e.strHomeTeam, score: e.intHomeScore }, away: { name: e.strAwayTeam, score: e.intAwayScore } },
    date: e.dateEvent, dateTime: { date: e.dateEvent, time: e.strTime }, venue: { name: e.strVenue },
    status: e.strStatus, season: e.strSeason
  }));
};

/** endpoint path -> fallback result, or null when there is no backup. */
async function fallback(endpoint, params = {}) {
  const m = endpoint.match(/^\/(epl|bundesliga|laliga|ligue1|seriea|ucl|euros|fifa)\/(upcomingmatches|matches|standings|scorers)$/);
  if (m) {
    const [, key, kind] = m;
    if (kind === 'standings') return standings(key);
    if (kind === 'scorers') return topScorers(key);
    return fixtures(key, kind === 'upcomingmatches' ? 'upcoming' : 'results');
  }
  switch (endpoint) {
    case '/fifa/scorers': return topScorers('fifa');
    case '/livescore': return liveScores();
    case '/livescore2': {
      const games = (await liveScores()).slice(0, 12);
      const list = await Promise.all(games.map(async game => {
        let playPath = '';
        if (game.eventId) {
          try {
            const summary = await get(`${ESPN}/site/v2/sports/soccer/all/summary`, { event: game.eventId });
            const video = summary.videos?.find(v => v.links?.web?.href);
            playPath = video?.links?.web?.href || '';
          } catch (_) {}
        }
        return {
          team1: { name: game.homeTeam, score: game.homeScore ?? '' },
          team2: { name: game.awayTeam, score: game.awayScore ?? '' },
          status: game.status,
          playPath
        };
      }));
      return { list };
    }
    case '/football/news': return news();
    case '/sport/playersearch': return players(params.q);
    case '/sport/teamsearch': return teams(params.q);
    case '/sport/venuesearch': return venues(params.q);
    case '/sport/gameevents': return gameEvents(params.q);
    default: return null;
  }
}

module.exports = { fallback, LEAGUES, findTeamLeagues };
