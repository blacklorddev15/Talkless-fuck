'use strict';
/**
 * Per-number data context.
 *
 * Every paired WhatsApp session (one socket per phone number) runs inside its
 * own AsyncLocalStorage scope, so the Talkless data layer can resolve a separate
 * data directory per number without touching command code.
 */
const { AsyncLocalStorage } = require('async_hooks');

const als = new AsyncLocalStorage();
const FALLBACK = 'default';

function current() {
  const store = als.getStore();
  return (store && store.session) || null;
}

function run(session, fn) {
  return als.run({ session: session || FALLBACK }, fn);
}

/**
 * Drop-in replacement for a plain `{}` used as a path -> parsed-JSON cache.
 * Keys are transparently prefixed with the active session id, so one session
 * never reads another session's cached file contents.
 */
class ScopedCache {
  constructor() {
    const store = Object.create(null);
    const key = (k) => `${current() || FALLBACK}|${String(k)}`;
    return new Proxy(store, {
      get(t, k) { return t[key(k)]; },
      set(t, k, v) { t[key(k)] = v; return true; },
      has(t, k) { return key(k) in t; },
      deleteProperty(t, k) { delete t[key(k)]; return true; },
    });
  }
}

module.exports = { current, run, ScopedCache, FALLBACK };
