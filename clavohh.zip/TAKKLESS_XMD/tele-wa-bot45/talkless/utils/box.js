/**
 * WhatsApp box formatter
 *
 *   ╔═════════════════╗
 *   ║  TITLE
 *   ╠═════════════════╣
 *   ║ line
 *   ╚═════════════════╝
 */
const TOP = '╔══════════════════════════╗';
const MID = '╠══════════════════════════╣';
const BOT = '╚══════════════════════════╝';
const BOX_CHARS = /(?:^|\n)\s*(?:╔|┏|╭|╓|┌)/;

const MAXW = 27;   // widest line (letters) that stays inside the frame
/** Word-wrap one line so no letter goes past the frame. Long unbreakable words (links) stay whole. */
function wrapLine(line, max = MAXW) {
  if ([...line].length <= max) return [line];
  const out = []; let cur = '';
  for (const w of line.split(' ')) {
    const next = cur ? cur + ' ' + w : w;
    if ([...next].length > max && cur) { out.push(cur); cur = w; } else cur = next;
  }
  if (cur) out.push(cur);
  return out;
}

/** Soft-wrap plain reply text for phone screens without changing its wording. */
function wrapText(text, max = 56) {
  return String(text).split('\n').flatMap(line => wrapLine(line, max)).join('\n');
}

function box(title, body = '', footer = '') {
  const lines = String(body || '').split('\n').flatMap(l => wrapLine(l));
  while (lines.length && !lines[0].trim()) lines.shift();
  while (lines.length && !lines[lines.length - 1].trim()) lines.pop();
  const out = [TOP];
  if (title) wrapLine(String(title), MAXW - 1).forEach((t, i) => out.push(i ? `║  ${t}` : `║  ${t}`));
  if (title && lines.length) out.push(MID);
  for (const l of lines) out.push(l.trim() ? `║ ${l}` : '║');
  if (footer) out.push(MID, `║ ${footer}`);
  out.push(BOT);
  return out.join('\n');
}

/** Boxes plain short text; leaves already-formatted or long text untouched. */
function autoBox(text, title = '') {
  if (typeof text !== 'string' || !text.trim()) return text;
  if (BOX_CHARS.test(text) || text.length > 1200) return text;
  return box(title, text);
}

/** Split a long boxed body into several boxes (WhatsApp ~4k char limit). */
function boxChunks(title, body, limit = 3500) {
  const chunks = [];
  let cur = '';
  for (const line of String(body).split('\n')) {
    if ((cur + line + '\n').length > limit && cur) { chunks.push(cur); cur = ''; }
    cur += line + '\n';
  }
  if (cur.trim()) chunks.push(cur);
  if (!chunks.length) chunks.push('_No data available_');
  return chunks.map((c, i) => box(chunks.length > 1 ? `${title} (${i + 1}/${chunks.length})` : title, c));
}

module.exports = { box, autoBox, boxChunks, BOX_CHARS, wrapLine, wrapText };
