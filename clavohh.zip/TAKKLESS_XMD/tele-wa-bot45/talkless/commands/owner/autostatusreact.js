const {
  loadSettings,
  saveSettings
} = require('../../database');
module.exports = {
  name: 'autostatusreact',
  aliases: ['statusreact', 'asr', 'autolikestatus'],
  category: 'owner',
  description: 'Auto-like WhatsApp statuses with rotating emoji reactions',
  usage: '.autostatusreact <on/off/get> (alias: .autolikestatus)',
  ownerOnly: true,
  async execute(sock, msg, args, extra) {
    try {
      const settings = loadSettings();
      const opt = (args[0] || '').toLowerCase();
      if (opt === 'on') {
        settings.react = true;
        settings.randomEmoji = true;
        if (!Array.isArray(settings.emojiPool) || !settings.emojiPool.length) {
          settings.emojiPool = ['🔥', '😍', '💙', '💚', '💜', '❤️', '🥰', '😎', '😂', '✨', '👏', '🎉'];
        }
        saveSettings(settings);
        const emojiInfo = '🎲 Uses different random emojis; set your pool with .autostatusemoji 🔥 😍 💙 ✨';
        return extra.reply(`💙 *Auto-like status ON*\n${emojiInfo}`);
      }
      if (opt === 'off') {
        settings.react = false;
        saveSettings(settings);
        return extra.reply('❌ *Auto-like status OFF*');
      }
      if (opt === 'get') {
        return extra.reply(`${settings.react ? '💙' : '❌'} Auto-like: *${settings.react ? 'ON' : 'OFF'}*`);
      }
      return extra.reply('⚠️ Use .autostatusreact <on/off/get>');
    } catch (error) {
      await extra.reply(`❌ Error: ${error.message}`);
    }
  }
};
