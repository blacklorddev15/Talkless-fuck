/**
 * AntiEdit — catches message edits and reveals the original content.
 */

const fs = require('fs');
const path = require('path');
const config = require(require('path').join(global.__ROOT__, 'config'));
const CONFIG_PATH = path.join(__dirname, '../../data/antiedit.json');
function loadConfig() {
  try {
    if (!fs.existsSync(CONFIG_PATH)) fs.writeFileSync(CONFIG_PATH, JSON.stringify({
      mode: 'pm'
    }, null, 2));
    return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  } catch {
    return {
      mode: 'pm'
    };
  }
}
function saveConfig(cfg) {
  try {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2));
  } catch {}
}
function getMode() {
  return loadConfig().mode || 'pm';
}
function setMode(mode) {
  saveConfig({
    mode
  });
}
// Per-session stores (each paired number has its own cache)
const sessionStores = new Map();
const handledEdits = new Set();
function sessionKey(sock) {
  const id = sock?.user?.id || sock?.__waNum || 'default';
  return String(id).split('@')[0].split(':')[0] || 'default';
}
function getStore(sock) {
  const k = sessionKey(sock);
  if (!sessionStores.has(k)) sessionStores.set(k, new Map());
  return sessionStores.get(k);
}
function unwrap(raw) {
  return raw?.ephemeralMessage?.message || raw?.viewOnceMessageV2?.message || raw?.viewOnceMessage?.message || raw?.documentWithCaptionMessage?.message || raw;
}
function textOf(m) {
  const i = unwrap(m) || {};
  return i.conversation || i.extendedTextMessage?.text || i.imageMessage?.caption || i.videoMessage?.caption || i.documentMessage?.caption || null;
}
function storeMessage(msg, sock) {
  try {
    if (!msg?.key?.id || !msg.message) return;
    const chatId = msg.key.remoteJid;
    if (!chatId || chatId === 'status@broadcast') return;
    const sender = msg.key.participant || (msg.key.fromMe ? (sock?.user?.id || chatId) : chatId);
    const text = textOf(msg.message);
    if (!text) return;
    const store = getStore(sock);
    if (!store.has(chatId)) store.set(chatId, new Map());
    const chatMap = store.get(chatId);
    chatMap.set(msg.key.id, {
      sender,
      fromMe: !!msg.key.fromMe,
      timestamp: msg.messageTimestamp,
      text,
      pushName: msg.pushName || null
    });
    if (chatMap.size > 500) chatMap.delete(chatMap.keys().next().value);
  } catch (_) {}
}
function botSelfJid(sock) {
  const id = sock.user?.id;
  if (!id) return null;
  return id.includes(':') ? id.split(':')[0] + '@s.whatsapp.net' : id;
}
async function handleAntiEdit(sock, updates) {
  const mode = getMode();
  if (mode === 'off') return;
  const selfJid = botSelfJid(sock);
  for (const {
    key,
    update
  } of updates) {
    try {
      const proto = update?.message?.protocolMessage;
      const newMsg = proto?.editedMessage || update?.message?.editedMessage?.message || null;
      if (!newMsg) continue;
      const chatId = key.remoteJid;
      const originalMsgId = proto?.key?.id || key.id;
      const targetJid = mode === 'chat' ? chatId : selfJid;
      if (!targetJid) continue;
      if (key.fromMe || proto?.key?.fromMe) continue;      // your own edits are not reported
      const original = getStore(sock).get(chatId)?.get(originalMsgId);
      if (original?.fromMe) continue;
      const originalText = original?.text || null;
      const rawSender = original?.sender || key.participant || key.remoteJid || '';
      const sender = rawSender.includes(':') ? rawSender.split(':')[0] + '@s.whatsapp.net' : rawSender;
      const senderNum = sender.split('@')[0];
      const editedText = textOf(newMsg);
      if (!editedText) continue;
      if (originalText && originalText === editedText) continue;
      const ek = sessionKey(sock) + '|' + chatId + '|' + originalMsgId + '|' + editedText;
      if (handledEdits.has(ek)) continue;
      handledEdits.add(ek);
      if (handledEdits.size > 5000) handledEdits.delete(handledEdits.values().next().value);
      const timestamp = original?.timestamp ? new Date(original.timestamp * 1000).toLocaleString('en-GB', {
        hour12: false,
        timeZone: config.timezone || 'Africa/Nairobi',
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }) : new Date().toLocaleString();
      const isGroup = chatId.endsWith('@g.us');
      let chatName = chatId.split('@')[0];
      if (isGroup) { try { chatName = (await sock.groupMetadata(chatId)).subject || chatName; } catch (_) {} }
      const { box } = require('../../utils/box');
      const where = isGroup ? `👥 ${chatName.length > 20 ? chatName.slice(0, 19) + '…' : chatName}` : '💬 Private chat';
      const head = box('✏️ EDITED MESSAGE', `👤 @${senderNum}\n${where}\n🕐 ${timestamp}`);
      const replyText = `${head}\n\n📝 *Original:*\n${originalText || '_Not cached (sent before the bot saw it)_'}\n\n✏️ *Edited to:*\n${editedText}`;
      await sock.sendMessage(targetJid, {
        text: replyText,
        mentions: sender ? [sender] : []
      });
      if (original) {
        original.text = editedText;   // so a second edit shows the previous edit as "Original"
      }
    } catch (e) {
      console.error('[ANTIEDIT] error:', e.message);
    }
  }
}
module.exports = {
  name: 'antiedit',
  aliases: ['antieditmsg', 'editdetect'],
  category: 'owner',
  description: 'Detect and reveal edited messages',
  usage: '.antiedit on | chat | off | status',
  adminOnly: true,
  storeMessage,
  handleAntiEdit,
  async execute(sock, msg, args, extra) {
    const {
      reply
    } = extra;
    const sub = (args[0] || '').toLowerCase();
    const mode = getMode();
    const statusLabel = mode === 'chat' ? '✅ ON — Chat' : mode === 'pm' ? '✅ ON — private chat' : '❌ OFF';
    if (!sub || sub === 'status') {
      return reply(`✏️ Anti-Edit: *${statusLabel}*\n\n.antiedit on | pm | chat | off`);
    }
    if (sub === 'chat') {
      setMode('chat');
      return reply('✏️ Anti-Edit set to *Chat* — edits revealed in the chat they happened in.');
    }
    if (sub === 'on' || sub === 'pm' || sub === 'private') {
      setMode('pm');
      return reply('✏️ Anti-Edit set to *ON — Private* — original + edited text are sent to your own chat (this number).');
    }
    if (sub === 'off') {
      setMode('off');
      return reply('✏️ Anti-Edit set to *OFF*.');
    }
    return reply('⚠️ Usage: .antiedit on | pm | chat | off | status');
  }
};