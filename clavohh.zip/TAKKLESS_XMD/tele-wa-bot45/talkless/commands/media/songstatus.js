const axios = require('axios');
const config = require('../../config');
const STATUS_API = 'https://api.omegatech.app/api/ai/sonu2';
module.exports = {
  name: 'songstatus',
  aliases: ['generatedsong', 'aistatus'],
  category: 'media',
  description: 'Check an Omegatech generated-song task and send ready tracks',
  usage: '.songstatus <taskId>',
  async execute(sock, msg, args, extra) {
    const taskId = (args[0] || '').trim();
    if (!taskId) return extra.reply(`🎼 Usage: ${config.prefix || '.'}songstatus <taskId>`);
    // Set OMEGATECH_SESSION on the bot host; never place a session credential in source/config files.
    const session = process.env.OMEGATECH_SESSION;
    if (!session) return extra.reply('⚙️ Song status needs OMEGATECH_SESSION to be set in the bot environment.');
    await extra.react?.('⏳');
    try {
      const response = await axios.get(STATUS_API, {
        params: { action: 'status', taskId, session },
        timeout: 30000
      });
      const body = response.data;
      const result = body?.success ? body.data : null;
      if (!result) throw new Error(body?.message || 'Status API returned no result');
      if (result.state !== 'ready' || !Array.isArray(result.songs) || result.songs.length === 0) {
        await extra.react?.('⏳');
        return extra.reply(`🎼 Task status: *${result.state || 'processing'}*\n${result.message || 'Check again shortly.'}`);
      }
      for (const song of result.songs) {
        if (!song.audioUrl) continue;
        const title = song.title || 'Generated song';
        await sock.sendMessage(extra.from, {
          audio: { url: song.audioUrl },
          mimetype: 'audio/mp4',
          ptt: false,
          fileName: `${title.replace(/[^\w\s.-]/g, '').slice(0, 80) || 'generated-song'}.m4a`,
          caption: `🎵 *${title}*${song.durationSecs ? `\n⏱️ ${song.durationSecs}s` : ''}`
        }, { quoted: msg });
      }
      await extra.react?.('✅');
    } catch (error) {
      console.error('[songstatus] error:', error.message);
      await extra.react?.('❌');
      await extra.reply('❌ Could not retrieve that generated-song task. Check the task ID and session, then retry.');
    }
  }
};
