const axios = require('axios');
const config = require('../../config');

const SEARCH_API = 'https://api.omegatech.app/api/Search/searchthatsong';
module.exports = {
  name: 'lyrics',
  aliases: ['lyric', 'lirik'],
  category: 'media',
  description: 'Search for a song from its title or lyric phrase',
  usage: '.lyrics <song or lyric phrase>',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply(`❌ Provide a song name or lyric phrase.\nExample: ${config.prefix || '.'}lyrics Isn't it a bit unethical?`);
    try {
      const response = await axios.get(SEARCH_API, {
        params: { action: 'search', query },
        timeout: 20000
      });
      const body = response.data;
      const song = body?.success ? body.data : null;
      if (!song) return extra.reply('❌ Could not identify a matching song. Try another phrase.');
      const source = song.webSources?.[0];
      const caption = [
        `🎵 *${song.song || 'Unknown Title'}*`,
        `👤 *Artist:* ${song.artist || 'Unknown Artist'}`,
        song.relevantChunk ? `\n📝 *Matching lyric excerpt:*\n_${song.relevantChunk}_` : '\n_No lyric excerpt was returned._',
        source?.url ? `\n🔗 *Source:* ${source.url}` : null,
        `\n_Note: this search API returns a matching excerpt, not necessarily full lyrics._`
      ].filter(Boolean).join('\n');
      if (song.albumArtwork) {
        await sock.sendMessage(extra.from, { image: { url: song.albumArtwork }, caption }, { quoted: msg });
      } else {
        await sock.sendMessage(extra.from, { text: caption }, { quoted: msg });
      }
    } catch (error) {
      console.error('[lyrics] search error:', error.message);
      await extra.reply('❌ Song search is unavailable right now. Please try again later.');
    }
  }
};
