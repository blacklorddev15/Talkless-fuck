const axios = require('axios');
const config = require('../../config');
const DOWNLOAD_API = 'https://api.omegatech.app/api/download/YouTube';
const YOUTUBE_URL = /https?:\/\/(?:www\.|m\.)?(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)[A-Za-z0-9_-]{11}/i;
const MAX_VIDEO_BYTES = 64 * 1024 * 1024;

module.exports = {
  name: 'youtube',
  aliases: ['yt', 'ytdl'],
  category: 'media',
  description: 'Download audio or video from a YouTube URL',
  usage: '.youtube <YouTube URL> [video|audio]',
  async execute(sock, msg, args, extra) {
    const input = args.join(' ').trim();
    const url = input.match(/https?:\/\/\S+/i)?.[0];
    const modeArg = args.find(arg => /^(audio|video)$/i.test(arg));
    const mode = (modeArg || 'video').toLowerCase();
    if (!url || !YOUTUBE_URL.test(url)) {
      return extra.reply(`❌ Send a valid YouTube video link.\nUsage: ${config.prefix || '.'}youtube <URL> [video|audio]`);
    }
    await extra.react?.('⏳');
    try {
      const response = await axios.get(DOWNLOAD_API, {
        params: { action: 'download', url, type: mode, bitrate: 128 },
        timeout: 45000
      });
      const body = response.data;
      const data = body?.success ? body.data : null;
      if (!data) throw new Error(body?.message || 'Downloader returned no data');
      const title = data.title || 'YouTube download';
      const cleanTitle = title.replace(/[^\w\s.-]/g, '').trim().slice(0, 90) || 'youtube-download';
      if (mode === 'audio') {
        const audio = data.audio?.mp3 || data.audio?.m4a;
        if (!audio?.downloadUrl) throw new Error('No audio download was returned');
        const isMp3 = Boolean(data.audio?.mp3?.downloadUrl);
        await sock.sendMessage(extra.from, {
          audio: { url: audio.downloadUrl },
          mimetype: isMp3 ? 'audio/mpeg' : 'audio/mp4',
          ptt: false,
          fileName: `${cleanTitle}.${isMp3 ? 'mp3' : 'm4a'}`,
          caption: `🎵 *${title}*\n👤 ${data.channel || 'YouTube'}\n\n*Downloaded by ${config.botName}*`
        }, { quoted: msg });
      } else {
        const formats = (data.videoFormats || []).filter(item => item?.downloadUrl && Number(item.sizeBytes) > 0);
        const fits = formats.filter(item => item.sizeBytes <= MAX_VIDEO_BYTES);
        const chosen = (fits.length ? fits : formats).sort((a, b) => b.height - a.height)[0];
        if (!chosen) throw new Error('No downloadable video format was returned');
        if (chosen.sizeBytes > MAX_VIDEO_BYTES) {
          return extra.reply(`⚠️ The smallest available video is ${chosen.sizeLabel || 'too large'} for reliable chat delivery. Try audio mode: ${config.prefix || '.'}youtube ${url} audio`);
        }
        await sock.sendMessage(extra.from, {
          video: { url: chosen.downloadUrl },
          mimetype: 'video/mp4',
          fileName: `${cleanTitle}.mp4`,
          caption: `🎬 *${title}*\n👤 ${data.channel || 'YouTube'}\n📺 ${chosen.label || `${chosen.height}p`}${chosen.sizeLabel ? ` · ${chosen.sizeLabel}` : ''}\n\n*Downloaded by ${config.botName}*`
        }, { quoted: msg });
      }
      await extra.react?.('✅');
    } catch (error) {
      console.error('[youtube] download error:', error.message);
      await extra.react?.('❌');
      await extra.reply('❌ YouTube download failed. The link may be unavailable or the API may be temporarily down.');
    }
  }
};
