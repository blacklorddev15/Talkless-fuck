/**
 * Ephoto360 Text Effects
 */

const axios = require('axios');
const config = require('../../config');
const { make } = require('../../utils/ephoto');
async function ephoto(url, text) {
  return (await make(url, text)).image;
}
function makeEphotoCmd(name, aliases, url, description) {
  return {
    name,
    aliases,
    category: 'textmaker',
    description,
    usage: `.${name} <text>`,
    async execute(sock, msg, args, extra) {
      const {
        from,
        reply
      } = extra || {};
      const chatId = from || msg.key.remoteJid;
      const text = args.join(' ');
      const prefix = config.prefix || '.';
      if (!text) {
        const replyFn = reply || (t => sock.sendMessage(chatId, {
          text: t
        }, {
          quoted: msg
        }));
        return replyFn(`*Example: ${prefix}${name} vin*`);
      }
      try {
        const result = await ephoto(url, text);
        await sock.sendMessage(chatId, {
          image: {
            url: result
          },
          caption: config.botName
        }, {
          quoted: msg
        });
      } catch (err) {
        console.error(`Error in ${name} command:`, err);
        const replyFn = reply || (t => sock.sendMessage(chatId, {
          text: t
        }, {
          quoted: msg
        }));
        replyFn(`*❌ Could not generate the effect right now.*\n_${String(err.message).slice(0, 80)} — please try again in a moment._`);
      }
    }
  };
}
function makeApiCmd(name, aliases, buildUrl, description, waitMsg, fallbackUrl) {
  return {
    name,
    aliases,
    category: 'textmaker',
    description,
    usage: `.${name} <text>`,
    async execute(sock, msg, args, extra) {
      const {
        from,
        reply
      } = extra || {};
      const chatId = from || msg.key.remoteJid;
      const text = args.join(' ');
      const prefix = config.prefix || '.';
      const replyFn = reply || (t => sock.sendMessage(chatId, {
        text: t
      }, {
        quoted: msg
      }));
      if (!text) return replyFn(`*Example: ${prefix}${name} vin*`);
      try {
        await replyFn(waitMsg);
        let imageUrl = buildUrl(encodeURIComponent(text));
        try {
          // make sure the external API really returns an image before sending
          const head = await axios.get(imageUrl, { responseType: 'arraybuffer', timeout: 15000 });
          if (!String(head.headers['content-type'] || '').startsWith('image/')) throw new Error('API did not return an image');
          await sock.sendMessage(chatId, { image: Buffer.from(head.data), caption: config.botName }, { quoted: msg });
        } catch (apiErr) {
          if (!fallbackUrl) throw apiErr;
          imageUrl = (await make(fallbackUrl, text)).image;   // ephoto360 scraper instead
          await sock.sendMessage(chatId, { image: { url: imageUrl }, caption: config.botName }, { quoted: msg });
        }
      } catch (err) {
        console.error(`Error in ${name} command:`, err);
        replyFn('❌ Error generating effect. Please try again later.');
      }
    }
  };
}
module.exports = [makeEphotoCmd('luxurygold', ['goldtext', 'goldfx'], 'https://en.ephoto360.com/create-a-luxury-gold-text-effect-online-594.html', 'Create a luxury gold text effect'), makeEphotoCmd('advancedglow', ['aglow'], 'https://en.ephoto360.com/advanced-glow-effects-74.html', 'Create an advanced glow text effect'), makeEphotoCmd('blackpinklogo', ['bplogo'], 'https://en.ephoto360.com/create-blackpink-logo-online-free-607.html', 'Create a Blackpink logo style text'), makeEphotoCmd('blackpinkstyle', ['bpstyle'], 'https://en.ephoto360.com/online-blackpink-style-logo-maker-effect-711.html', 'Create a Blackpink style text effect'), makeEphotoCmd('cartoonstyle', ['cartoonfx'], 'https://en.ephoto360.com/create-a-cartoon-style-graffiti-text-effect-online-668.html', 'Create a cartoon style graffiti text effect'), makeEphotoCmd('deadpool', ['deadpoolfx'], 'https://en.ephoto360.com/create-light-effects-green-neon-online-429.html', 'Create a green neon light text effect'), makeEphotoCmd('effectclouds', ['cloudsfx'], 'https://en.ephoto360.com/write-text-effect-clouds-in-the-sky-online-619.html', 'Write text in clouds in the sky'), makeEphotoCmd('flagtext', ['flagfx'], 'https://en.ephoto360.com/nigeria-3d-flag-text-effect-online-free-753.html', 'Create a 3D flag text effect'), makeEphotoCmd('freecreate', ['freefx'], 'https://en.ephoto360.com/free-create-a-3d-hologram-text-effect-441.html', 'Create a 3D hologram text effect'), makeEphotoCmd('galaxystyle', ['galaxyfx'], 'https://en.ephoto360.com/create-galaxy-style-free-name-logo-438.html', 'Create a galaxy style name logo'), makeEphotoCmd('galaxywallpaper', ['galaxywp'], 'https://en.ephoto360.com/create-galaxy-wallpaper-mobile-online-528.html', 'Create a galaxy wallpaper with your text'), makeEphotoCmd('makingneon', ['makeneon'], 'https://en.ephoto360.com/making-neon-light-text-effect-with-galaxy-style-521.html', 'Create neon light text with galaxy style'), makeEphotoCmd('matrixfx', ['matrixtext'], 'https://en.ephoto360.com/matrix-text-effect-154.html', 'Create a matrix style text effect'), makeEphotoCmd('royaltext', ['royalfx'], 'https://en.ephoto360.com/royal-text-effect-online-free-471.html', 'Create a royal text effect'), makeEphotoCmd('sandfx', ['sandtext'], 'https://en.ephoto360.com/write-in-sand-summer-beach-online-576.html', 'Write text in sand on a beach'), makeEphotoCmd('summerbeach', ['beachfx'], 'https://en.ephoto360.com/write-in-sand-summer-beach-online-free-595.html', 'Write text on a summer beach'), makeEphotoCmd('topography', ['topofx'], 'https://en.ephoto360.com/create-typography-text-effect-on-pavement-online-774.html', 'Create typography text effect on pavement'), makeEphotoCmd('typography', ['typefx'], 'https://en.ephoto360.com/create-typography-text-effect-on-pavement-online-774.html', 'Create a typography pavement text effect'), makeEphotoCmd('flag3dtext', ['flag3d'], 'https://en.ephoto360.com/free-online-american-flag-3d-text-effect-generator-725.html', 'Create a 3D American flag text effect'), makeEphotoCmd('glitchtext', ['textglitch'], 'https://en.ephoto360.com/create-digital-glitch-text-effects-online-767.html', 'Create a digital glitch text effect'), makeEphotoCmd('dragonball', ['dragonballfx'], 'https://en.ephoto360.com/create-dragon-ball-style-text-effects-online-809.html', 'Create a Dragon Ball style text effect'), makeEphotoCmd('multicoloredneon', ['multicneon'], 'https://en.ephoto360.com/create-multicolored-neon-light-signatures-591.html', 'Create multicolored neon light signatures'), makeEphotoCmd('neonglitch', ['neonglitchfx'], 'https://en.ephoto360.com/create-impressive-neon-glitch-text-effects-online-768.html', 'Create impressive neon glitch text effect'), makeEphotoCmd('papercutstyle', ['papercutfx'], 'https://en.ephoto360.com/multicolor-3d-paper-cut-style-text-effect-658.html', 'Create a 3D multicolor paper cut style text'), makeEphotoCmd('pixelglitch', ['pixelglitchfx'], 'https://en.ephoto360.com/create-pixel-glitch-text-effect-online-769.html', 'Create a pixel glitch text effect'), makeEphotoCmd('glowingtext', ['glowtxt'], 'https://en.ephoto360.com/create-glowing-text-effects-online-706.html', 'Create glowing text effect'), makeEphotoCmd('gradienttext', ['gradienttxt'], 'https://en.ephoto360.com/create-3d-gradient-text-effect-online-600.html', 'Create a 3D gradient text effect'), makeEphotoCmd('graffiti', ['graffitifx'], 'https://en.ephoto360.com/cute-girl-painting-graffiti-text-effect-667.html', 'Create a graffiti text effect'), makeEphotoCmd('incandescent', ['incandescentfx'], 'https://en.ephoto360.com/text-effects-incandescent-bulbs-219.html', 'Create incandescent bulb text effect'), makeEphotoCmd('lighteffects', ['lightfx'], 'https://en.ephoto360.com/create-light-effects-green-neon-online-429.html', 'Create light/neon text effects'), makeEphotoCmd('logomaker', ['logomake'], 'https://en.ephoto360.com/free-bear-logo-maker-online-673.html', 'Create a bear logo with text'), makeApiCmd('royal', ['royal2'], t => `https://api.nekolabs.my.id/ephoto/royal-text?text=${t}`, 'Create a royal logo (via external API)', '👑 Creating royal logo... Please wait ⏳', 'https://en.ephoto360.com/royal-text-effect-online-free-471.html'), makeApiCmd('textonwetglass', ['wetglass', 'wetfx'], t => `https://api.nekolabs.web.id/ephoto/text-on-wet-glass?text=${t}`, 'Create a wet glass text effect (via external API)', '💧 Creating text on wet glass effect... Please wait ⏳'), makeApiCmd('bear', ['bearlogo'], t => `https://api.nekolabs.my.id/ephoto/bear-logo?text=${t}`, 'Create a bear logo (via external API)', '🐻 Creating bear logo... Please wait ⏳', 'https://en.ephoto360.com/free-bear-logo-maker-online-673.html'), makeApiCmd('papercut', ['3dpaper', 'paper3d'], t => `https://api.nekolabs.my.id/ephoto/3d-paper-cut-style?text=${t}`, 'Create a 3D paper cut style (via external API)', '✂️ Creating 3D paper cut style... Please wait ⏳', 'https://en.ephoto360.com/multicolor-3d-paper-cut-style-text-effect-658.html'), makeApiCmd('hologram', ['3dhologram', 'hologram3d'], t => `https://api.nekolabs.my.id/ephoto/3d-hologram-text?text=${t}`, 'Create a 3D hologram text (via external API)', '✨ Creating 3D hologram text... Please wait ⏳', 'https://en.ephoto360.com/free-create-a-3d-hologram-text-effect-441.html')];