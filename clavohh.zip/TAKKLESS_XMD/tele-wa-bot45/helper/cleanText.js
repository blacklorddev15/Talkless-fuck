'use strict';
/**
 * cleanText — keeps bot replies compact and clean.
 *
 *  - removes horizontal divider lines (━━━, ───, ═══, ----- ...) and the box
 *    corners/bars that frame them (╭─ ╰─ ┏━ │ ...)
 *  - turns "━━━ TITLE ━━━" style headers into just "TITLE"
 *  - collapses runs of blank lines
 *  - leaves fenced ``` code blocks alone (tables / monospace output keep their shape)
 *
 * Used for every outgoing WhatsApp message (sock.sendMessage) and every
 * Telegram message (telegram.callApi), so ALL command replies are covered.
 */

const H_RUN   = /[╭╮╰╯┏┓┗┛┌┐└┘╔╗╚╝╠╣☆]?(?:[━─═▬╌┄┈]\s?){2,}[╭╮╰╯┏┓┗┛┌┐└┘╔╗╚╝╠╣☆]?/g;
const H_ONLY  = /^\s*(?:[━─═▬╌┄┈]\s?){3,}\s*$/;
const ASCII_SEP = /^\s*(?:[-=_~]\s?){5,}\s*$/;
const BOX_CHARS = '╭╮╰╯┏┓┗┛┌┐└┘│┃║╔╗╚╝╠╣';
const EDGE_DECOR = new RegExp('^[\\s•⪩›⋆☆' + BOX_CHARS + ']+|[\\s•⪩›⋆☆' + BOX_CHARS + ']+$', 'g');
const EDGE_BOX   = new RegExp('^[' + BOX_CHARS + ']\\s*|\\s*[' + BOX_CHARS + ']$', 'g');
const QUICK = /[━─═▬╌┄┈╭╮╰╯┏┓┗┛┌┐└┘│┃║╔╗╚╝╠╣]|(?:[-=_~]\s?){5,}/;

function cleanText(input) {
  if (typeof input !== 'string' || input.length < 3) return input;
  if (!QUICK.test(input)) return input.replace(/\n{3,}/g, '\n\n');   // nothing to strip: just tidy blank lines

  const out = [];
  let fenced = false;
  for (const line of input.split('\n')) {
    if (/^\s*```/.test(line)) { fenced = !fenced; out.push(line); continue; }

    if (fenced) {                       // monospace blocks: only drop pure divider lines
      if (H_ONLY.test(line)) continue;
      out.push(line);
      continue;
    }

    if (ASCII_SEP.test(line) || H_ONLY.test(line)) continue;   // pure divider line

    if (H_RUN.test(line)) {             // decorated header / frame line
      H_RUN.lastIndex = 0;
      const cleaned = line.replace(H_RUN, ' ').replace(/[━─═▬╌┄┈]+/g, ' ').replace(EDGE_DECOR, '').replace(/\s{2,}/g, ' ').trim();
      if (cleaned) out.push(cleaned);
      continue;
    }
    H_RUN.lastIndex = 0;

    if (/[│┃║╭╮╰╯┏┓┗┛┌┐└┘╔╗╚╝╠╣]/.test(line)) {   // leftover frame bars
      const cleaned = line.replace(EDGE_BOX, '');
      if (cleaned.trim() || !line.trim()) out.push(cleaned);
      continue;
    }
    out.push(line);
  }

  let text = out.join('\n').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n');
  return text.replace(/^\n+/, '');
}

// ── WhatsApp: keep our ╔═══╗ boxes, and put every plain reply inside one ───────
const { box } = require('../talkless/utils/box');
let _botName = 'TALKLESS XMD';
try { _botName = require('../talkless/config').botName || _botName; } catch (_) {}
const OURS = /^[ \t]*╔═+╗[\s\S]*╚═+╝/m;          // already one of our boxes -> hands off

// Title = a short first line followed by a blank line ("*Usage:*\n\n..."); otherwise the bot name.
function splitTitle(text) {
  const m = text.match(/^([^\n]{2,32})\n\n([\s\S]+)$/);
  if (m && !/[.:!?]$/.test(m[1].replace(/\*|_/g, '').trim()) || (m && /^\*.*\*$/.test(m[1].trim()))) {
    return { title: m[1].replace(/^[*_]+|[*_]+$/g, '').trim(), body: m[2] };
  }
  return { title: `✦ ${_botName} ✦`, body: text };
}

function shouldBox(content, jid) {
  if (!content || typeof content.text !== 'string') return false;
  if (content.edit || content.react || content.poll || content.delete) return false;
  if (Object.keys(content).some(k => /^(image|video|audio|document|sticker|contacts|location|buttons|sections|interactiveButtons|templateButtons)$/.test(k))) return false;
  if (typeof jid === 'string' && /status@broadcast|@newsletter/.test(jid)) return false;
  const t = content.text;
  if (t.length < 2 || t.length > 3500 || t.includes('```')) return false;
  if ((content.mentions || []).length >= 5) return false;        // tagall / hidetag must stay untouched
  return true;
}

const WA_FIELDS = ['text', 'caption'];
function cleanWaContent(content, jid) {
  if (!content || typeof content !== 'object') return content;
  let copy = null;
  for (const f of WA_FIELDS) {
    const v = content[f];
    if (typeof v !== 'string' || OURS.test(v)) continue;        // leave our boxes alone
    const c = cleanText(v);
    if (c !== v) { copy = copy || { ...content }; copy[f] = c; }
  }
  const cur = copy || content;
  if (typeof cur.text === 'string' && !OURS.test(cur.text) && shouldBox(cur, jid)) {
    // old-style header "┏━━『 TITLE 』━━" on the first line -> use TITLE as the box title
    const h = typeof content.text === 'string' && content.text.match(/^[^\n]*『\s*([^』\n]+?)\s*』[^\n]*\n([\s\S]*)$/);
    const { title, body } = h ? { title: h[1], body: cleanText(h[2]).trim() } : splitTitle(cur.text.trim());
    copy = { ...cur, text: box(title, body) };
  }
  return copy || content;
}

/** WhatsApp: wrap sock.sendMessage once. */
function patchWhatsApp(sock) {
  if (!sock || sock.__cleanTextPatched || typeof sock.sendMessage !== 'function') return sock;
  const orig = sock.sendMessage.bind(sock);
  sock.sendMessage = (jid, content, ...rest) => {
    let c = content;
    try { c = cleanWaContent(content, jid); } catch (_) {}
    return orig(jid, c, ...rest);
  };
  sock.__cleanTextPatched = true;
  return sock;
}

const TG_TEXT    = new Set(['sendMessage', 'editMessageText']);
const TG_CAPTION = new Set(['sendPhoto', 'sendVideo', 'sendDocument', 'sendAnimation', 'sendAudio', 'sendVoice', 'editMessageCaption', 'copyMessage']);
/** Telegram (Telegraf): wrap telegram.callApi once. */
function patchTelegram(bot) {
  const tg = bot && bot.telegram;
  if (!tg || tg.__cleanTextPatched || typeof tg.callApi !== 'function') return bot;
  const orig = tg.callApi.bind(tg);
  tg.callApi = (method, data, ...rest) => {
    let d = data;
    try {
      if (d && typeof d === 'object') {
        if (TG_TEXT.has(method) && typeof d.text === 'string') {
          const c = cleanText(d.text); if (c !== d.text) d = { ...d, text: c };
        } else if (TG_CAPTION.has(method) && typeof d.caption === 'string') {
          const c = cleanText(d.caption); if (c !== d.caption) d = { ...d, caption: c };
        }
      }
    } catch (_) {}
    return orig(method, d, ...rest);
  };
  tg.__cleanTextPatched = true;
  return bot;
}

module.exports = { cleanText, patchWhatsApp, patchTelegram };
