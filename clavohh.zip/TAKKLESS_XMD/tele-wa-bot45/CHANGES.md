# Changes
1. **Boxed WhatsApp replies** – `talkless/utils/box.js` (╔═══╗ / ║ / ╚═══╝). Short plain `extra.reply()` texts are boxed
   automatically (handler.js). Turn off with `boxReplies: false` in talkless/config.js. Play + sports output is boxed too.
2. **Faster music** – `talkless/utils/fastDownload.js`: all download providers are asked at the same time (first answer wins,
   20s cap instead of 3 retries x 60s per provider), YouTube + Omegatech search run in parallel, results cached 30 min,
   `.play2` pre-fetches the link while you pick a format and sends by URL (no temp file).
3. **Sports fallback** – `talkless/utils/sportsFallback.js`: if the Keith API is down/empty, ESPN + TheSportsDB answer
   (livescore, fixtures, results, standings, news, player/team/venue/h2h search, FIFA/EPL/UCL/...). 8s timeout, 45s cache.
   Top-scorer commands and `.bet` still need the Keith API (no free backup).
4. **Text-maker fix** – `talkless/utils/ephoto.js`: rewrote the ephoto360 scraper (proper multipart boundary via `form-data`,
   multi-text/style effects, 2 retries, `mumaker` as last resort). All `textmaker/*` and `ephoto360/*` commands use it;
   the 4 external-API effects (royal, bear, papercut, hologram) fall back to it. Use `a|b` for effects needing two texts.
5. **Smart menu** – `talkless/utils/menuLayout.js` (used by `.menu`, all 6 menu styles): every category is a ╔══╗ box,
   commands show as `║╠ .command`, grouped into sub-sections (e.g. Admin → Members / Tagging / Protection / Welcome / Settings;
   Media → Music / Video / Downloaders; Sports → Live / Leagues / FIFA / Search). Junk entries (`cta_url`, `cta_copy`, ~190 country
   names) are hidden; reactions/anime/logos are packed 2-3 per line. Edit the `LAYOUT` table in that file to regroup.
6. **Menu v2** – titles in bold-sans font, group labels in small caps, every line packed to fit one phone line (no wrapping);
   the menu picture (`menuImageUrl` in talkless/config.js) is shown on top with the header, followed by the sections as clean text
   blocks; the "Loading…" message was removed; footer/“Powered by” now reads **TALKLESS TECH** (`poweredBy` in talkless/config.js).
7. **Branding** – pairing code is now `TALKLESS` (was `BLACKSKY`, index.js); bot name set to `TALKLESS XMD` everywhere
   (settings.js, talkless/config.js, talkless/database.js, talkless/utils/settings.js, menu/ping/etc.). No "BLACKLORD XMD" exists in the code.
   If you still see it on WhatsApp, it was saved at runtime: send `.setbotname TALKLESS XMD`.
8. index.js: the "PAIR BLACKLORD XMD" button (written in fancy italic letters, so a normal search missed it) and its
   click handler now both say "PAIR TALKLESS XMD".
9. Menu is now ONE box in ONE message (header, how-to and every category stacked inside a single ╔══╗…╚══╝), with the menu
   picture attached to that same message. (menuLayout.js `buildMenuParts` -> `full`.)
10. `.menu` (every menu style): ONE message = menu picture + the whole menu as its caption + Ping button at the bottom.
    Falls back to image+caption, then text, if the button message is rejected.
11. `.botinfo` / `.botstatus` use the same style as the menu: one box (bold title, small-caps section labels, `║╠ Key ➜ value`
    rows kept to one line), menu picture on top, Ping / Uptime / Restart buttons at the bottom (talkless/utils/infoCard.js).
12. **All replies in the box** – `helper/cleanText.js` (global WhatsApp send filter) no longer strips box characters, so the
    menu/info/sports boxes survive; every other plain text reply is wrapped automatically in ╔═══╗ / ║ title / ╠═══╣ / ╚═══╝
    (old `┏━━『 TITLE 』━━` headers become the box title, "*Title*\n\n..." too, otherwise the bot name). Skipped on purpose:
    edits, reactions, media, code blocks, status posts, tag-all/hidetag (5+ mentions) and texts over 3500 chars.
13. **Anti-delete → private chat** – every message deleted (text, image, video, audio, sticker, document, contact, location, poll)
    is delivered to the paired number's own chat. Messages are now cached the moment they arrive (index.js `talklessBridge.store`),
    so none are missed. Every recovered message is also saved in `talkless/data/deleted-log.json` (last 100, per number).
    `.antidelete on` = private chat, `chat` = same chat, `off`, `status`,
    **`.antidelete fetch [n]`** (also `.deleted`) replays ALL saved deleted messages to your private chat, `clear` empties the log.
14. **Anti-edit → private chat** – shows original + edited text in the paired number's own chat (`.antiedit on|chat|off|status`),
    same boxed style, also cached at arrival.
15. **Menu frame** – the frame is wider (26 ═) and every line is cut/wrapped to fit inside it, so no letter goes past the border
    (menu, bot info cards and all boxed replies: `box.js` wraps long lines, `menuLayout.js` shortens header rows).
16. **TALKLESS MUSIC `.play`** (talkless/commands/media/song.js, aliases song/yta/music/tmusic) – search (Omegatech + YouTube at once),
    song card with thumbnail sent immediately while all download providers race, audio sent by link; falls back to buffer, then document.
17. **Status reactions** – auto status react now uses a different emoji on every status (random from a 30-emoji default pool or your
    own list from `.autostatusemoji 🔥 😍 💙 ✨`, never the same one twice in a row). Only a single emoji set with
    `.autostatusemoji <emoji>` keeps it fixed; `.autostatusemoji random on` switches back to random.
18. **"Waiting for this message" fix** – index.js socket now has `getMessage` (recent sent/received messages are remembered),
    a `msgRetryCounterCache` and retry settings, so when a phone cannot decrypt a message and asks the bot to send it again
    (retry receipt) the bot can answer instead of leaving the chat stuck on "Waiting for this message".
19. **Telegram keyboard trimmed** – the 17 reply-keyboard buttons are now only the important ones:
    users: Pair TALKLESS XMD · Del Pair · Generate Session · Report Issues · My Profile · Buy Panel;
    owner also gets Broadcast and Owner Menu. Every other feature is still available as a /command.
    New: **Report Issues** button (asks for the problem, forwards it to the owner who can reply in the chat) and **Broadcast** button (owner).
    Fixed: keyboard buttons that "typed" a /command used to send it from the bot itself (which never runs); they now run it as the user.
20. **Menu audio** – `.menu` now sends your audio (talkless/utils/menu_audio.mp3, 1:08) right after the menu message.
    Replace that file to change the song.
21. **Renamed to Talkless** – the command-pack folder is now `talkless/` and its bridge is `talklessBridge.js`; every old name in code,
    comments, temp folders, sticker pack id and docs is now Talkless. NOTE: on an existing host, per-number data (paired numbers'
    settings) is still in the previous pack folder's `database/numbers` and `data/numbers`; copy those two folders into
    `talkless/database/` and `talkless/data/` when upgrading.
22. **Old external services removed** – the external pair service, the chatbot API URL / bot id / built-in API key and every old name are gone.
    Add yours in `talkless/config.js` (or as environment variables of the same name): `PAIR_API_URL` (used by `.pair`, expects
    `<url>/code?number=...` returning `{ "code": "..." }`), `TALKLESS_API_URL`, `TALKLESS_BOT_ID`, `TALKLESS_API_KEY` (chatbot API).
    Until set, `.pair` says the URL is not set and the chatbot stays idle. The antibot whitelist now only matches "talkless".
