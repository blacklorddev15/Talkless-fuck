'use strict';
/**
 * talklessBridge — mounts the TALKLESS command pack (talkless/) inside this bot,
 * with per-number data isolation.
 *
 * Every message is dispatched inside an AsyncLocalStorage scope keyed by the
 * paired number (sock.user.id), so talkless/database and talkless/data resolve to
 * talkless/{database,data}/numbers/<number>/ for that session only.
 */
const path = require('path');

// The obfuscated Talkless command modules call global.log(msg, color). The original
// Talkless runtime defines it in its own index.js; this host never did, so any
// failed log call threw "global[...] is not a function" and killed the process.
if (typeof global.log !== 'function') {
  global.log = (msg, color) => {
    if (color) console.log(String(msg));
    else console.log(String(msg));
  };
}

global.__CORE__ = path.join(__dirname, 'talkless');
global.__ROOT__ = path.join(__dirname, 'talkless');

// installs the per-number fs remap BEFORE the Talkless modules are loaded
const sessionFs = require('./talkless/sessionFs');

let _handler = null;

function load() {
  if (!_handler) {
    _handler = require('./talkless/handler');
    console.log(`[TALKLESS] command pack mounted — ${_handler.getCommandCount()} commands`);
  }
  return _handler;
}

// ─── Auto status view / react ────────────────────────────────
const _DEFAULT_STATUS_EMOJIS = ['🔥','😍','💙','💚','💜','❤️','🥰','😎','😂','🤩','👏','🙌','✨','💯','🎉','😮','🤭','💖','😻','👌','🫶','🥳','💫','😁','🤝','🙏','🌟','😇','🤗','💪'];
const _statusHandled = new Set();

// Shuffle the full pool and use each emoji once before reshuffling. This gives
// statuses varied reactions without repeats until the configured pool cycles.
const _emojiCycles = new Map();
function pickStatusEmoji(st, sock) {
  // The persisted setting is authoritative; do not rely on a separate marker
  // file that may be absent or stored in a different per-number data folder.
  if (!st.randomEmoji) return st.emoji || '💙';
  const configuredPool = Array.isArray(st.emojiPool)
    ? st.emojiPool.filter(e => typeof e === 'string' && e.trim())
    : [];
  const pool = [...new Set(configuredPool.length ? configuredPool : _DEFAULT_STATUS_EMOJIS)];
  const key = String(sock?.user?.id || '').split(':')[0];
  const signature = pool.join('|');
  let cycle = _emojiCycles.get(key);
  if (!cycle || cycle.signature !== signature) cycle = { signature, bag: [], last: null };
  if (!cycle.bag.length) {
    cycle.bag = pool.slice();
    for (let i = cycle.bag.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [cycle.bag[i], cycle.bag[j]] = [cycle.bag[j], cycle.bag[i]];
    }
    if (cycle.bag.length > 1 && cycle.bag[0] === cycle.last) {
      [cycle.bag[0], cycle.bag[1]] = [cycle.bag[1], cycle.bag[0]];
    }
  }
  const pick = cycle.bag.shift() || '💙';
  cycle.last = pick;
  _emojiCycles.set(key, cycle);
  return pick;
}

async function handleStatusImpl(sock, msg) {
  const key = msg?.key;
  if (!key || key.remoteJid !== 'status@broadcast' || key.fromMe || !msg.message) return;
  if (msg.message.protocolMessage || msg.message.reactionMessage) return;
  const participant = key.participant || msg.participant || key.participantAlt || msg.participantAlt;
  if (!participant) {
    console.warn('[STATUS] skipped status without a participant JID:', key.id || '(no id)');
    return;
  }

  const session = sessionFs.sessionFromSock(sock) || 'default';
  const dedupe = session + '|' + key.id + '|' + participant;
  if (_statusHandled.has(dedupe)) return;
  _statusHandled.add(dedupe);
  if (_statusHandled.size > 2000) _statusHandled.delete(_statusHandled.values().next().value);

  const db = require('./talkless/database');
  const st = db.loadSettings();
  if (!st.enabled && !st.react) return;

  // random human-like delay so many sessions don't act in the same instant
  await new Promise(r => setTimeout(r, 1500 + Math.floor(Math.random() * 4500)));
  // Re-read after the delay so an owner's OFF command takes effect immediately
  // for any status that is still waiting to be viewed or reacted to.
  const currentSettings = db.loadSettings();

  if (currentSettings.enabled) {
    try { await sock.readMessages([key]); }
    catch (e) { console.error('[STATUS] view failed:', e.message); }
  }

  if (currentSettings.react) {
    const emoji = pickStatusEmoji(currentSettings, sock);
    const me = sock.user?.id;
    try {
      await sock.sendMessage(key.remoteJid,
        { react: { text: emoji, key } },
        { statusJidList: [participant, me].filter(Boolean) });
    } catch (e) { console.error('[STATUS] react failed:', e.message); }
  }
}

module.exports = {
  async handle(sock, msg) {
    const session = sessionFs.sessionFromSock(sock) || 'default';
    return sessionFs.runWithSession(session, async () => {
      try {
        return await load().handleMessage(sock, msg);
      } catch (e) {
        console.error('[TALKLESS] handler error:', e && e.message);
      }
    });
  },
  // Auto view / auto react for WhatsApp statuses (status@broadcast).
  initializeStatusSettings(sock) {
    const session = sessionFs.sessionFromSock(sock) || 'default';
    return sessionFs.runWithSession(session, () => require('./talkless/database').loadSettings());
  },
  handleStatus(sock, msg) {
    const session = sessionFs.sessionFromSock(sock) || 'default';
    return sessionFs.runWithSession(session, async () => {
      try { return await handleStatusImpl(sock, msg); } catch (e) {
        console.error('[STATUS] auto view/react error:', e && e.message);
      }
    });
  },
  // Cache every incoming message the moment it arrives (antidelete / antiedit need the original).
  store(sock, msg) {
    try { load().storeForAnti(sock, msg); } catch (_) {}
  },
  // Deleted messages: from messages.update (stub REVOKE) ...
  handleMessagesUpdate(sock, updates) {
    const session = sessionFs.sessionFromSock(sock) || 'default';
    return sessionFs.runWithSession(session, async () => {
      try { return await load().handleMessagesUpdate(sock, updates); } catch (e) {
        console.error('[TALKLESS] messages.update error:', e && e.message);
      }
    });
  },
  // ... and from protocolMessage REVOKE notices in messages.upsert.
  handleRevoke(sock, items) {
    const session = sessionFs.sessionFromSock(sock) || 'default';
    return sessionFs.runWithSession(session, async () => {
      try { return await load().handleRevokes(sock, items); } catch (e) {
        console.error('[TALKLESS] revoke error:', e && e.message);
      }
    });
  },
  // Edited messages arriving as protocolMessage (type 14) in messages.upsert.
  handleEdit(sock, items) {
    const session = sessionFs.sessionFromSock(sock) || 'default';
    return sessionFs.runWithSession(session, async () => {
      try { return await load().handleEdits(sock, items); } catch (e) {
        console.error('[TALKLESS] edit error:', e && e.message);
      }
    });
  },
  handleGroupUpdate(sock, update) {
    const session = sessionFs.sessionFromSock(sock) || 'default';
    return sessionFs.runWithSession(session, async () => {
      try { return await load().handleGroupUpdate(sock, update); } catch (e) {
        console.error('[TALKLESS] group update error:', e && e.message);
      }
    });
  },
  initAntiCall(sock) {
    try { return load().initializeAntiCall(sock); } catch (e) {
      console.error('[TALKLESS] anticall error:', e && e.message);
    }
  },
  get count() {
    try { return load().getCommandCount(); } catch { return 0; }
  },
  preload() { load(); },
};
